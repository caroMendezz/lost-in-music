-- Ejecutar UNA VEZ en la base de datos real (MySQL) antes de reiniciar el backend.
-- sequelize.sync() no agrega columnas a tablas que ya existen.
ALTER TABLE messages
  ADD COLUMN deletedForAll TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN deletedBySender TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN deletedByReceiver TINYINT(1) NOT NULL DEFAULT 0;
