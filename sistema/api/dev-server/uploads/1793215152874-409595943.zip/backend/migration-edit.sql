-- Ejecutar UNA VEZ en la base de datos real (MySQL) antes de reiniciar el backend.
-- (Es independiente de migration.sql: solo agrega la columna de edicion.)
ALTER TABLE messages
  ADD COLUMN editedAt DATETIME NULL;
